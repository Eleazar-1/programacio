public class Act6 {
    public static void main(String[] args) {
        int media1 = 7;
        int media2 = 8;

        System.out.printf("Media de las dos notas es: "+ (media1 + media2) / 2.0 );
    }
}
