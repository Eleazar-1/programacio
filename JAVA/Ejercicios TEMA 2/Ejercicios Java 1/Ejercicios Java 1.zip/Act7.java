public class Act7 {
    public static void main(String[] args) {
        double radio = 6;
        int exponente = 2;
        double resultado= Math.pow(radio, exponente); //Unir base y exponente

        double pi = Math.PI;

        System.out.println("La longitud de la circunferencia es: "+ 2 * pi * radio+ " cm.");
        System.out.println("El area de la circunferencia es: "+ pi * resultado + " cm.");
    }
}
