import java.util.Scanner;

public class Act5 {
    public static void main(String[] args) {
        short valor = 32767;
        valor++;
        //valor = valor +1
        //valor +=1;
        System.out.println("Muestrame el valor: " + valor);
    }
}
