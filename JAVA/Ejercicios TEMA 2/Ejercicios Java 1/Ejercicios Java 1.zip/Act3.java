import java.util.Scanner;

public class Act3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Escribe tu edad: ");
        int numero = sc.nextInt();

        numero = numero +1;
        System.out.println("Tendras el año que viene: " + numero);
        
        
    }
}
