public class Act20 {
    public static void main(String[] args) {
        
        double altura = 8;
        double radio = 3;
        double exponente = 2;

        double volumen = (Math.PI * Math.pow(radio, exponente) * altura) /3;

        System.out.println("El volumen es: "+ volumen);

    }
}
