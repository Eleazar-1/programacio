import java.util.Scanner;

public class Act9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);//Scanner

        System.out.println("Escribe un numero: ");
        int numero = sc.nextInt(); //El programa lee el numero

        boolean par = (numero % 2 == 0);

        if (par) {
            System.out.println("El número es par.");
        } else {
            System.out.println("El número no es par.");
        }
    }
}
