import java.util.Scanner;

public class act7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int siete = 7;

        for (int i = 1; i <= 14; i++) {
            System.out.println("Multiplos de 7: "+(i*siete));

        }

        sc.close();
    }
}
